/*
 * @Author: Wei Daiheng
 * @Date: 2022-08-01 20:45:12
 * @LastEditors: Wei Daiheng
 * @LastEditTime: 2022-08-05 17:17:50
 * @FilePath: \F103ZET6_USART&FLASH_INPUT_SAVE_OUTPUT (1)\User\main.c
 * @Description:
 *
 * Copyright (c) 2022 by Wei Daiheng, All Rights Reserved.
 */

/*
 *                                                     __----~~~~~~~~~~~------___
 *                                    .  .   ~~//====......          __--~ ~~
 *                    -.            \_|//     |||\\  ~~~~~~::::... /~
 *                 ___-==_       _-~o~  \/    |||  \\            _/~~-
 *         __---~~~.==~||\=_    -_--~/_-~|-   |\\   \\        _/~
 *     _-~~     .=~    |  \\-_    '-~7  /-   /  ||    \      /
 *   .~       .~       |   \\ -_    /  /-   /   ||      \   /
 *  /  ____  /         |     \\ ~-_/  /|- _/   .||       \ /
 *  |~~    ~~|--~~~~--_ \     ~==-/   | \~--===~~        .\
 *           '         ~-|      /|    |-~\~~       __--~~
 *                       |-~~-_/ |    |   ~\_   _-~            /\
 *                            /  \     \__   \/~                \__
 *                        _--~ _/ | .-~~____--~-/                  ~~==.
 *                       ((->/~   '.|||' -_|    ~~-/ ,              . _||
 *                                  -_     ~\      ~~---l__i__i__i--~~_/
 *                                  _-~-__   ~)  \--______________--~~
 *                                //.-~~~-~_--~- |-------~~~~~~~~
 *                                       //.-~~~--\
 *                       ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 */

#include "stm32f10x.h"
#include "sys.h"
#include "delay.h"
#include "led.h"
#include "usart.h"
#include "flash.h"
#include "crc.h"

/**
 * 	红灯亮起：等待PC数据发送
 * 	绿灯亮起：数据正在收发
 * @return {*}
 */
int main(void)
{
	// u8 i; //临时存储打印数据
	RCC_Configuration();							//时钟设置
	LED_Init();										//初始化LED
	USART1_Init(115200);							//串口初始化（参数是波特率）
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_3); //设置中断优先级分组2:2位抢占优先级，2位响应优先级

	while (1)
	{
		if (Receive_Flag == 1) //接收数据标志位,1接收完毕，停止接收，0可以开始接收
			Receive_Flag = 0;

		if (system_flag == 0) //系统总线标志位，防止读取数据时总线被锁死；时间标志位，方便的计时
		{
			if (send_flag == 0)
			{
				LED0 = 1;
				LED1 = 0;
				
				if (CRC16BitCheck((u8 *)usart1_string_temp, Receive_data_len))
				{
					USART_SendString(USART1, usart1_string_temp); //发送数据
					send_flag = 1;
				}
				else
				{
					//printf("CRC校验错误\n");
					send_flag = 1;
				}
			}

			// STMFLASH_Read(FLASH_SAVE_ADDR, (u16 *)usart2_string_temp, SIZE);//读FLASH
			else
			{
				LED1 = 1;
				LED0 = 0;
			}
		}
	}
}
