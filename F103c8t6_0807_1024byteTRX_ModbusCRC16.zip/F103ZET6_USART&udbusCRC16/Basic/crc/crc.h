/*
 * @Author: Wei Daiheng
 * @Date: 2022-08-05 15:29:51
 * @LastEditors: Wei Daiheng
 * @LastEditTime: 2022-08-05 17:15:41
 * @FilePath: \F103ZET6_USART&FLASH_INPUT_SAVE_OUTPUT (1)\Basic\crc\crc.h
 * @Description: modbusCRC16校验算法
 *
 * Copyright (c) 2022 by Wei Daiheng, All Rights Reserved.
 */
#ifndef __CRC_H__
#define __CRC_H__
#include "sys.h"
#include "usart.h"
#include "stdbool.h"

//extern u16 polynom; //多项式
extern u16 receive_crc16_value; //初始值
extern u16 data_crc16_value;




u16 CRC16BitGet(u8 *ptr, u16 len);
bool CRC16BitCheck(u8 *ptr, u16 len);


#endif
