
#include "stm32f10x.h" //STM32头文件
#include "sys.h"
#include "delay.h"
#include "led.h"
#include "usart.h"
#include "flash.h"

const u8 Start_Buffer[] = {"No Message reveive"};
#define SIZE sizeof(Start_Buffer)

int main(void)
{ //主程序
	// u8 numOfString = 4;
	u8 usart2_string_temp[SIZE]; // u8 a;
	u8 i;
	//初始化程序
	// u8 *usart2_string;
	RCC_Configuration();							//时钟设置
	LED_Init();										//初始化LED
	USART1_Init(115200);							//串口初始化（参数是波特率）
	USART2_Init(115200);							//串口初始化（参数是波特率）
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_3); //设置中断优先级分组2:2位抢占优先级，2位响应优先级

	STMFLASH_Write(FLASH_SAVE_ADDR, (u16 *)Start_Buffer, SIZE);
	//主循环
	while (1)
	{
		if (Receive_Flag == 1) //接收数据标志位等于1（接收完毕，停止接收）
			Receive_Flag = 0;  //接收数据标志位置0（可以开始接收）

		if (system_flag == 0)
		{
			STMFLASH_Read(FLASH_SAVE_ADDR, (u16 *)usart2_string_temp, SIZE);
			for (i = 0; i < SIZE; i++)
			{
				if (usart2_string_temp[i] == '\0')
				{
					printf("\n");
					break;
				}
				else
					printf("%c", usart2_string_temp[i]);
				// usart2_string[i] = usart2_string_temp[i];
			}
			// USART2_printf("now, string is :%c\n", usart2_string);
			//发送数据
			//发送FLASH中的数据
		}else{
			LED1 = !LED1;
			delay_ms(200);
			continue;
		}

		LED0 = !LED0;	// LED闪烁
		delay_ms(1000); //延时
	}
}
