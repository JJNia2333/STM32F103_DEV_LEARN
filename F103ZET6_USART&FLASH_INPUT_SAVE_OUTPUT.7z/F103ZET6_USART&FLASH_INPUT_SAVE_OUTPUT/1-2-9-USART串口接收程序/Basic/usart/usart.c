
/*
//杜洋工作室出品
//洋桃系列开发板应用程序
//关注微信公众号：洋桃电子
//洋桃开发板资料下载 www.DoYoung.net/YT
//即可免费看所有教学视频，下载技术资料，技术疑难提问
//更多内容尽在 杜洋工作室主页 www.doyoung.net
*/

/*
《修改日志》
1-201708271933 加入了秒延时函数。


*/

#include "sys.h"
#include "usart.h"
#include "flash.h"

//使UASRT串口可用printf函数发送
//在usart.h文件里可更换使用printf函数的串口号
#if 1
#pragma import(__use_no_semihosting)
//标准库需要的支持函数
struct __FILE
{
    int handle;
};
FILE __stdout;
//定义_sys_exit()以避免使用半主机模式
_sys_exit(int x)
{
    x = x;
}
//重定义fputc函数
int fputc(int ch, FILE *f)
{
    while ((USART_n->SR & 0X40) == 0)
        ; //循环发送,直到发送完毕
    USART_n->DR = (u8)ch;
    return ch;
}
#endif

/*
USART1串口相关程序
*/

#if EN_USART1 // USART1使用与屏蔽选择

/*
USART1专用的printf函数
当同时开启2个以上串口时，printf函数只能用于其中之一，其他串口要自创独立的printf函数
调用方法：USART1_printf("123"); //向USART2发送字符123
*/
void USART1_printf(char *fmt, ...)
{
    char buffer[USART1_REC_LEN + 1]; // 数据长度
    u8 i = 0;
    va_list arg_ptr;
    va_start(arg_ptr, fmt);
    vsnprintf(buffer, USART1_REC_LEN + 1, fmt, arg_ptr);
    while ((i < USART1_REC_LEN) && (i < strlen(buffer)))
    {
        USART_SendData(USART1, (u8)buffer[i++]);
        while (USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET)
            ;
    }
    va_end(arg_ptr);
}

void USART1_Init(u32 bound)
{ //串口1初始化并启动
    // GPIO端口设置
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_GPIOA, ENABLE); //使能USART1，GPIOA时钟
                                                                                  // USART1_TX   PA.9
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;                                     // PA.9
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; //复用推挽输出
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    // USART1_RX	  PA.10
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING; //浮空输入
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    // Usart1 NVIC 配置
    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;                       //抢占优先级3
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;                              //子优先级3
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;                                 // IRQ通道使能
    NVIC_Init(&NVIC_InitStructure);                                                 //根据指定的参数初始化VIC寄存器
                                                                                    // USART 初始化设置
    USART_InitStructure.USART_BaudRate = bound;                                     //一般设置为9600;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;                     //字长为8位数据格式
    USART_InitStructure.USART_StopBits = USART_StopBits_1;                          //一个停止位
    USART_InitStructure.USART_Parity = USART_Parity_No;                             //无奇偶校验位
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None; //无硬件数据流控制
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;                 //收发模式
    USART_Init(USART1, &USART_InitStructure);                                       //初始化串口
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);                                  //开启ENABLE/关闭DISABLE中断
    USART_Cmd(USART1, ENABLE);                                                      //使能串口
}

//---------------------------------------------------------------------------
void USART_SendString(USART_TypeDef *USARTx, char *DataString)
{
    int i = 0;
    USART_ClearFlag(USARTx, USART_FLAG_TC); //发送字符前清空标志位（否则缺失字符串的第一个字符）
    while (DataString[i] != '\0')           //字符串结束符
    {
        USART_SendData(USARTx, DataString[i]); //每次发送字符串的一个字符
        while (USART_GetFlagStatus(USARTx, USART_FLAG_TC) == 0)
            ;                                   //等待数据发送成功
        USART_ClearFlag(USARTx, USART_FLAG_TC); //发送字符后清空标志位
        i++;
    }
}

char USART_ReceiveString[50]; //接收PC端发送过来的字符
int Receive_Flag = 0;         //接收消息标志位
int Receive_sum = 0;          //数组下标
int system_flag = 0;          //系统标志位
void USART1_IRQHandler(void)
{
    system_flag = 1;
    if (USART_GetITStatus(USART1, USART_IT_RXNE) == 1) // USART_FLAG_RXNE判断数据，== 1则有数据
    {
        if (Receive_sum > 49) //数组能存放50个字节的数据
        {
            USART_ReceiveString[49] = '\0'; //数据字节超过50位时，将最后一位设置为\0
            Receive_Flag = 1;               //接收标志位置1，停止接收数据
            Receive_sum = 0;                //数组下标置0
        }

        if (Receive_Flag == 0) //接收标志位等于0，开始接收数据
        {
            USART_ReceiveString[Receive_sum] = USART_ReceiveData(USART1); //通过USART1串口接收字符
            Receive_sum++;                                                //数组下标++
        }

        if (Receive_sum >= 2) //数组下标大于2
        {
            if (USART_ReceiveString[Receive_sum - 2] == '\r' && USART_ReceiveString[Receive_sum - 1] == '\n')
            {
                USART_ReceiveString[Receive_sum - 1] = '\0';
                USART_ReceiveString[Receive_sum - 2] = '\0';
                Receive_Flag = 1; //接收标志位置1，停止接收数据
                Receive_sum = 0;  //数组下标置0
                STMFLASH_Write(FLASH_SAVE_ADDR, (u16 *)USART_ReceiveString, strlen(USART_ReceiveString)); //将接收到的数据写入FLASH
                system_flag = 0;
            }
        }
        USART_ClearITPendingBit(USART1, USART_IT_RXNE); //接收后先清空标志位
    }
}
//---------------------------------------------------------------------------
#endif
/*
USART2串口相关程序
*/
#if EN_USART2                     // USART2使用与屏蔽选择
u8 USART2_RX_BUF[USART2_REC_LEN]; //接收缓冲,最大USART_REC_LEN个字节.
//接收状态
// bit15，	接收完成标志
// bit14，	接收到0x0d
// bit13~0，	接收到的有效字节数目
u16 USART2_RX_STA = 0; //接收状态标记

/*
USART2专用的printf函数
当同时开启2个以上串口时，printf函数只能用于其中之一，其他串口要自创独立的printf函数
调用方法：USART2_printf("123"); //向USART2发送字符123
*/
void USART2_printf(char *fmt, ...)
{
    char buffer[USART2_REC_LEN + 1]; // 数据长度
    u8 i = 0;
    va_list arg_ptr;
    va_start(arg_ptr, fmt);
    vsnprintf(buffer, USART2_REC_LEN + 1, fmt, arg_ptr);
    while ((i < USART2_REC_LEN) && (i < strlen(buffer)))
    {
        USART_SendData(USART2, (u8)buffer[i++]);
        while (USART_GetFlagStatus(USART2, USART_FLAG_TC) == RESET)
            ;
    }
    va_end(arg_ptr);
}

void USART2_Init(u32 bound)
{ //串口1初始化并启动
    // GPIO端口设置
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);  //使能UART2所在GPIOA的时钟
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE); //使能串口的RCC时钟

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;             //设置USART2的RX接口是PA3
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING; //浮空输入
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2; //设置USART2的TX接口是PA2
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; //复用推挽输出
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // USART2 初始化设置
    USART_InitStructure.USART_BaudRate = bound;                                     //一般设置为9600;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;                     //字长为8位数据格式
    USART_InitStructure.USART_StopBits = USART_StopBits_1;                          //一个停止位
    USART_InitStructure.USART_Parity = USART_Parity_No;                             //无奇偶校验位
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None; //无硬件数据流控制
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;                 //收发模式
    USART_Init(USART2, &USART_InitStructure);                                       //初始化串口
    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);                                  //开启ENABLE/关闭DISABLE中断
    USART_Cmd(USART2, ENABLE);                                                      //使能串口
                                                                                    // Usart2 NVIC 配置
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
    NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3; //抢占优先级3
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;        //优先级3
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;           // IRQ通道使能
    NVIC_Init(&NVIC_InitStructure);                           //根据指定的参数初始化VIC寄存器
}

void USART2_IRQHandler(void)
{ //串口2中断服务程序（固定的函数名不能修改）
}
#endif

#if EN_USART3                     //如果使能了接收
u8 USART3_RX_BUF[USART3_REC_LEN]; //接收缓冲,最大USART_REC_LEN个字节.
//接收状态
// bit15，	接收完成标志
// bit14，	接收到0x0d
// bit13~0，	接收到的有效字节数目
u16 USART3_RX_STA = 0; //接收状态标记

/*
USART3专用的printf函数
当同时开启2个以上串口时，printf函数只能用于其中之一，其他串口要自创独立的printf函数
调用方法：USART3_printf("123"); //向USART3发送字符123
*/
void USART3_printf(char *fmt, ...)
{
    char buffer[USART3_REC_LEN + 1]; // 数据长度
    u8 i = 0;
    va_list arg_ptr;
    va_start(arg_ptr, fmt);
    vsnprintf(buffer, USART3_REC_LEN + 1, fmt, arg_ptr);
    while ((i < USART3_REC_LEN) && (i < strlen(buffer)))
    {
        USART_SendData(USART3, (u8)buffer[i++]);
        while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET)
            ;
    }
    va_end(arg_ptr);
}

void USART3_Init(u32 BaudRate)
{ // USART3初始化并启动
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);  //使能UART3所在GPIOB的时钟
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE); //使能串口的RCC时钟

    //串口使用的GPIO口配置
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;            //设置USART3的RX接口是PB11
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING; //接口模式 浮空输入
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;        //设置USART3的TX接口是PB10
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; //输出速度50MHz
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;   //接口模式 复用推挽输出
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    //配置串口
    USART_InitStructure.USART_BaudRate = BaudRate;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;                     //字长为8位数据格式
    USART_InitStructure.USART_StopBits = USART_StopBits_1;                          //一个停止位
    USART_InitStructure.USART_Parity = USART_Parity_No;                             //无奇偶校验位
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None; //无硬件数据流控制
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;                 //收发模式

    USART_Init(USART3, &USART_InitStructure);      //配置串口3
    USART_ITConfig(USART3, USART_IT_RXNE, ENABLE); //使能串口接收中断
    // USART_ITConfig(USART3, USART_IT_TXE, ENABLE);//串口发送中断在发送数据时开启
    USART_Cmd(USART3, ENABLE); //使能串口3

    //串口中断配置
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
    NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;  //允许USART3中断
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0; //中断等级
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

//串口3中断服务程序（固定的函数名不能修改）
void USART3_IRQHandler(void)
{
}
#endif

/*********************************************************************************************
 * 杜洋工作室 www.DoYoung.net
 * 洋桃电子 www.DoYoung.net/YT
 *********************************************************************************************/

/*
a符号的作用：

%d 十进制有符号整数
%u 十进制无符号整数
%f 浮点数
%s 字符串
%c 单个字符
%p 指针的值
%e 指数形式的浮点数
%x, %X 无符号以十六进制表示的整数
%o 无符号以八进制表示的整数
%g 自动选择合适的表示法
%p 输出地址符

*/
