/*
 * @Author: Wei Daiheng
 * @Date: 2022-08-01 20:45:12
 * @LastEditors: Wei Daiheng
 * @LastEditTime: 2022-08-02 11:03:40
 * @FilePath: \F103ZET6_USART&FLASH_INPUT_SAVE_OUTPUT\User\main.c
 * @Description: 
 * 
 * Copyright (c) 2022 by Wei Daiheng, All Rights Reserved. 
 */


/*
 *                                                     __----~~~~~~~~~~~------___
 *                                    .  .   ~~//====......          __--~ ~~
 *                    -.            \_|//     |||\\  ~~~~~~::::... /~
 *                 ___-==_       _-~o~  \/    |||  \\            _/~~-
 *         __---~~~.==~||\=_    -_--~/_-~|-   |\\   \\        _/~
 *     _-~~     .=~    |  \\-_    '-~7  /-   /  ||    \      /
 *   .~       .~       |   \\ -_    /  /-   /   ||      \   /
 *  /  ____  /         |     \\ ~-_/  /|- _/   .||       \ /
 *  |~~    ~~|--~~~~--_ \     ~==-/   | \~--===~~        .\
 *           '         ~-|      /|    |-~\~~       __--~~
 *                       |-~~-_/ |    |   ~\_   _-~            /\
 *                            /  \     \__   \/~                \__
 *                        _--~ _/ | .-~~____--~-/                  ~~==.
 *                       ((->/~   '.|||' -_|    ~~-/ ,              . _||
 *                                  -_     ~\      ~~---l__i__i__i--~~_/
 *                                  _-~-__   ~)  \--______________--~~
 *                                //.-~~~-~_--~- |-------~~~~~~~~
 *                                       //.-~~~--\
 *                       ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * 
 */



#include "stm32f10x.h"
#include "sys.h"
#include "delay.h"
#include "led.h"
#include "usart.h"
#include "flash.h"

#define SIZE 1024

/**
 * @description: 
 * 	红灯闪烁：等待PC数据发送
 * 	微机接收数据存储，发送回PC，并开始计时，此时绿灯闪烁
 * @return {*}
 */
int main(void)
{ 
	u8 i, usart2_string_temp[SIZE];					//临时存储打印数据

	RCC_Configuration();							//时钟设置
	LED_Init();										//初始化LED
	USART1_Init(115200);							//串口初始化（参数是波特率）
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_3); //设置中断优先级分组2:2位抢占优先级，2位响应优先级

	while (1)
	{
		if (Receive_Flag == 1) //接收数据标志位,1接收完毕，停止接收，0可以开始接收
			Receive_Flag = 0;  

		if (system_flag == 0 && time_flag) //系统总线标志位，防止读取数据时总线被锁死；时间标志位，方便的计时
		{
			STMFLASH_Read(FLASH_SAVE_ADDR, (u16 *)usart2_string_temp, SIZE);//读FLASH
			for (i = 0; i < SIZE; i++) //读取到的数据串口打印
			{
				if (usart2_string_temp[i] == '\0')
				{
					printf(":\r%d\n", time_flag);
					break;
				}
				else
					printf("%c", usart2_string_temp[i]);
			}

			time_flag++;

			if (time_flag == 60) //检查计时
			{
				time_flag = 0;
			}

			LED1 = !LED1;  
			delay_ms(999); 
		}
		else
		{
			LED0 = !LED0;
			delay_ms(200);
		}
	}
}
